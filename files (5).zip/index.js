require('dotenv').config();

// Start both services
require('./server');
require('./bot');
