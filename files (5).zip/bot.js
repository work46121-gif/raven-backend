const { Client, GatewayIntentBits, REST, Routes, SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { createClient } = require('@supabase/supabase-js');

const TOKEN = process.env.BOT_TOKEN;
const CLIENT_ID = process.env.CLIENT_ID;

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

function generateBillId() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let id = '';
  for (let i = 0; i < 5; i++) id += chars[Math.floor(Math.random() * chars.length)];
  return id;
}

function formatMoney(amount) {
  return `$${parseFloat(amount).toFixed(2)}`;
}

// ─── REGISTER SLASH COMMANDS ─────────────────────────────────────────────────

const commands = [
  new SlashCommandBuilder()
    .setName('split')
    .setDescription('Split a bill among people')
    .addStringOption(opt => opt.setName('name').setDescription('Bill name').setRequired(true))
    .addNumberOption(opt => opt.setName('total').setDescription('Total amount').setRequired(true))
    .addStringOption(opt => opt.setName('people').setDescription('Mention people e.g. @Alex @Mia').setRequired(true)),
  new SlashCommandBuilder()
    .setName('paid')
    .setDescription('Mark yourself as paid on a bill')
    .addStringOption(opt => opt.setName('id').setDescription('Bill ID').setRequired(true)),
  new SlashCommandBuilder()
    .setName('remind')
    .setDescription('Remind everyone who still owes (creator only)')
    .addStringOption(opt => opt.setName('id').setDescription('Bill ID').setRequired(true)),
  new SlashCommandBuilder()
    .setName('status')
    .setDescription('Check the status of a bill')
    .addStringOption(opt => opt.setName('id').setDescription('Bill ID').setRequired(true)),
  new SlashCommandBuilder()
    .setName('bills')
    .setDescription('List all active bills in this server'),
].map(cmd => cmd.toJSON());

const rest = new REST({ version: '10' }).setToken(TOKEN);
(async () => {
  try {
    await rest.put(Routes.applicationCommands(CLIENT_ID), { body: commands });
    console.log('🪶 RAVEN Discord slash commands registered.');
  } catch (err) {
    console.error('Failed to register Discord commands:', err);
  }
})();

// ─── CLIENT ──────────────────────────────────────────────────────────────────

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
  ]
});

client.once('ready', () => {
  console.log(`🪶 RAVEN Discord bot online as ${client.user.tag}`);
});

// ─── INTERACTIONS ─────────────────────────────────────────────────────────────

client.on('interactionCreate', async interaction => {
  if (!interaction.isChatInputCommand()) return;
  const { commandName } = interaction;

  // /split
  if (commandName === 'split') {
    const name = interaction.options.getString('name');
    const total = interaction.options.getNumber('total');
    const peopleRaw = interaction.options.getString('people');

    const mentionRegex = /<@!?(\d+)>/g;
    const mentionedIds = [];
    let match;
    while ((match = mentionRegex.exec(peopleRaw)) !== null) mentionedIds.push(match[1]);

    if (mentionedIds.length === 0) {
      return interaction.reply({ content: '❌ Please mention at least one person using @username.', ephemeral: true });
    }

    const perPerson = total / mentionedIds.length;
    const billId = generateBillId();
    const discordCreatorId = interaction.user.id;

    // Save to Supabase — use discord: prefix to distinguish from SMS creators
    const { error: billError } = await supabase.from('bills').insert({
      id: billId,
      creator_phone: `discord:${discordCreatorId}`,
      name,
      total,
      per_person: perPerson,
      guild_id: interaction.guildId
    });

    if (billError) {
      console.error('Discord SPLIT error:', billError);
      return interaction.reply({ content: '❌ Failed to create bill. Try again.', ephemeral: true });
    }

    const participantRows = mentionedIds.map(uid => ({
      bill_id: billId,
      phone: `discord:${uid}`,
      name: `<@${uid}>`,
      amount: perPerson,
      paid: false
    }));

    await supabase.from('participants').insert(participantRows);

    const mentions = mentionedIds.map(uid => `<@${uid}>`).join(', ');
    const rows = mentionedIds.map(uid => `⏳ <@${uid}> — **${formatMoney(perPerson)}**`).join('\n');

    const embed = new EmbedBuilder()
      .setColor(0x5865F2)
      .setTitle(`🪶 ${name} — New Split!`)
      .setDescription(`${mentions} — <@${discordCreatorId}> covered **${name}** · you each owe **${formatMoney(perPerson)}**`)
      .addFields(
        { name: 'Bill ID', value: `\`${billId}\``, inline: true },
        { name: 'Total', value: formatMoney(total), inline: true },
        { name: 'Per Person', value: formatMoney(perPerson), inline: true },
        { name: 'Status', value: rows }
      )
      .setFooter({ text: `Use /paid ${billId} to mark yourself · /remind ${billId} to ping owes` });

    await interaction.reply({ embeds: [embed] });
  }

  // /paid
  else if (commandName === 'paid') {
    const id = interaction.options.getString('id').toUpperCase();
    const uid = interaction.user.id;

    const { data: bill } = await supabase.from('bills').select('*').eq('id', id).single();
    if (!bill) return interaction.reply({ content: `❌ No bill found with ID \`${id}\`.`, ephemeral: true });

    const { data: participant } = await supabase
      .from('participants').select('*').eq('bill_id', id).eq('phone', `discord:${uid}`).single();

    if (!participant) return interaction.reply({ content: `❌ You're not on this bill.`, ephemeral: true });
    if (participant.paid) return interaction.reply({ content: `✅ You've already marked yourself as paid on **${bill.name}**.`, ephemeral: true });

    await supabase.from('participants').update({ paid: true, paid_at: new Date().toISOString() }).eq('id', participant.id);

    const { data: allParts } = await supabase.from('participants').select('*').eq('bill_id', id);
    const paidCount = allParts.filter(p => p.paid).length;
    const totalCount = allParts.length;
    const allPaid = paidCount === totalCount;

    if (allPaid) await supabase.from('bills').update({ status: 'completed' }).eq('id', id);

    const rows = allParts.map(p => `${p.paid ? '✅' : '⏳'} ${p.name} — **${formatMoney(p.amount)}**`).join('\n');

    const embed = new EmbedBuilder()
      .setColor(allPaid ? 0x57F287 : 0x5865F2)
      .setTitle(`🪶 ${bill.name} — Updated`)
      .addFields({ name: 'Status', value: rows })
      .setFooter({ text: allPaid ? `🎉 Everyone's settled up!` : `${paidCount}/${totalCount} paid` });

    await interaction.reply({ embeds: [embed] });
  }

  // /remind
  else if (commandName === 'remind') {
    const id = interaction.options.getString('id').toUpperCase();
    const uid = interaction.user.id;

    const { data: bill } = await supabase.from('bills').select('*').eq('id', id).single();
    if (!bill) return interaction.reply({ content: `❌ No bill found with ID \`${id}\`.`, ephemeral: true });
    if (bill.creator_phone !== `discord:${uid}`) {
      return interaction.reply({ content: `❌ Only the bill creator can send reminders.`, ephemeral: true });
    }

    const { data: unpaid } = await supabase.from('participants').select('*').eq('bill_id', id).eq('paid', false);

    if (!unpaid || unpaid.length === 0) {
      return interaction.reply({ content: `✅ Everyone has paid on **${bill.name}**! 🎉` });
    }

    const owes = unpaid.map(p => `${p.name} (${formatMoney(p.amount)})`).join(', ');

    await interaction.reply({
      content: `🔔 **Reminder — ${bill.name}** (\`${id}\`)\n\nStill owe: ${owes}\n\nUse \`/paid ${id}\` when you've sent your share!`
    });
  }

  // /status
  else if (commandName === 'status') {
    const id = interaction.options.getString('id').toUpperCase();

    const { data: bill } = await supabase.from('bills').select('*').eq('id', id).single();
    if (!bill) return interaction.reply({ content: `❌ No bill found with ID \`${id}\`.`, ephemeral: true });

    const { data: participants } = await supabase.from('participants').select('*').eq('bill_id', id);
    const paidCount = participants.filter(p => p.paid).length;
    const totalCount = participants.length;
    const rows = participants.map(p => `${p.paid ? '✅' : '⏳'} ${p.name} — **${formatMoney(p.amount)}**`).join('\n');

    const embed = new EmbedBuilder()
      .setColor(0x5865F2)
      .setTitle(`🪶 ${bill.name} — Status`)
      .addFields(
        { name: 'Bill ID', value: `\`${id}\``, inline: true },
        { name: 'Total', value: formatMoney(bill.total), inline: true },
        { name: 'Per Person', value: formatMoney(bill.per_person), inline: true },
        { name: 'Breakdown', value: rows }
      )
      .setFooter({ text: `${paidCount}/${totalCount} paid` });

    await interaction.reply({ embeds: [embed] });
  }

  // /bills
  else if (commandName === 'bills') {
    const { data: guildBills } = await supabase
      .from('bills')
      .select('*, participants(*)')
      .eq('guild_id', interaction.guildId)
      .eq('status', 'active')
      .order('created_at', { ascending: false })
      .limit(10);

    if (!guildBills || guildBills.length === 0) {
      return interaction.reply({ content: `📋 No active bills in this server. Use \`/split\` to create one!`, ephemeral: true });
    }

    const lines = guildBills.map(b => {
      const paidCount = (b.participants || []).filter(p => p.paid).length;
      const total = (b.participants || []).length;
      return `\`${b.id}\` **${b.name}** — ${formatMoney(b.total)} · ${paidCount}/${total} paid`;
    }).join('\n');

    const embed = new EmbedBuilder()
      .setColor(0x5865F2)
      .setTitle('🪶 Active Bills')
      .setDescription(lines);

    await interaction.reply({ embeds: [embed] });
  }
});

client.login(TOKEN);
